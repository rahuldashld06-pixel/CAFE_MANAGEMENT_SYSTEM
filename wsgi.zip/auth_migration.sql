-- Authentication and ownership migration for the Cafe Management System.
-- The Flask application also performs this migration automatically on startup.
-- Run this manually only if you prefer database migrations outside the app.

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    role ENUM('admin','manager','cashier') NOT NULL DEFAULT 'cashier',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add these columns if they do not already exist:
-- ALTER TABLE foods ADD COLUMN user_id INT NULL;
-- ALTER TABLE orders ADD COLUMN user_id INT NULL;

-- Existing rows should be assigned to the initial administrator before
-- making user_id NOT NULL or adding foreign keys.
